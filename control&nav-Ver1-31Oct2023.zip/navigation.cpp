#include "esim/util.h"
#include "esim/quat.h"
#include "rmax/onboard_ref.h"
#include "rmax/sensors_ref.h"
#include "rmax/navigation_ref.h"
#include "rmax/navigation.h"
#include "rmax/motion_ref.h"  /* to allow use of truth data */


struct kalman_filter {
	float state_estimate;
	float estimate_covariance;
	float process_noise;
	float measurement_noise;
};

void kalman_predict(struct kalman_filter* kf) {
	kf->estimate_covariance += kf->process_noise;
}

void kalman_update(struct kalman_filter* kf, double measurement) {
	float kalman_gain = kf->estimate_covariance / (kf->estimate_covariance + kf->measurement_noise);
	kf->state_estimate += kalman_gain * (measurement - kf->state_estimate);
	kf->estimate_covariance = (1 - kalman_gain) * kf->estimate_covariance;
}

double kfupdate(double value)
{
	static struct kalman_filter kf;
	kf.process_noise = 0.01; // example value
	kf.measurement_noise = 0.1; // example value

	// Prediction step
	kalman_predict(&kf);
	kalman_update(&kf, value);
	return kf.state_estimate;
}

void updateNavigation(struct onboard_ref* ob)
{
	/* truth data */
	struct vehicle_ref* v = &vehicle;
	struct motionXforms_ref* xforms = v->motion->xforms;
	struct state_ref* state = v->motion->state;
	struct state_ref* std = v->motion->stateDot;	// to get accel

	/* emulated sensor data */
	struct sensors_ref* sen = ob->sensors;
	struct navigation_ref* nav = ob->navigation;
	struct navout_ref* out = nav->out;

	struct senImu_ref* imu = sen->imu; // imu sensor (gyroscope + accelermeter)
	struct imuOut_ref* imu_kf = imu->out;
	double kf_imu_angular[3];
	double kf_imu_force[3];

	for (int i = 0; i < 3; i++)
	{
		out->kf_imu_angular[i] = kfupdate(imu_kf->w_b_e_B[i]);
		out->kf_imu_force[i] = kfupdate(imu_kf->s_b_e_B[i]);
	}


	struct senAGL_ref* agl = sen->agl; // above ground level sensor (sonar)
	struct aglOut_ref* agl_kf = agl->out;

	double kf_agl_altitude = kfupdate(agl_kf->altitude);
	out->kf_agl_altitude = kf_agl_altitude;


	struct senGps_ref* gps = sen->gps; // gps sensor
	struct gpsOut_ref* gps_kf = gps->out;
	double kf_gps_position[3];
	double kf_gps_velocity[3];

	for (int i = 0; i < 3; i++)
	{
		out->kf_gps_position[i] = kfupdate(gps_kf->p_b_e_L[i]);
		out->kf_gps_velocity[i] = kfupdate(gps_kf->v_b_e_L[i]);
	}



	struct senMagnet_ref* mag = sen->magnet; // magnetometer
	struct magnetOut_ref* mag_kf = mag->out;

	double kf_mag_field[3];

	for (int i = 0; i < 3; i++)
	{
		out->kf_mag_field[i] = kfupdate(mag_kf->field_B[i]);

	}

	/* navigation filter */


	/*
	static struct kalman_filter kf;
	kf.process_noise = 0.01; // example value
	kf.measurement_noise = 0.1; // example value

	// Prediction step
	kalman_predict(&kf);

	// Update step with AGL sensor measurement
	kalman_update(&kf, height);
	*/
	//double height = agl->sonar0->out->altitude;
	// Store the estimated state in the navigation output
	//ob->navigation->out->altitudeMSL = kfupdate(height);


	out->itime++;
	out->time = out->itime * nav->set->imuDt;
	int a = out->a;
	if (a == 0)
	{
		for (int i = 0; i < 3; i++)
		{

			out->p_b_e_L[i] = state->p_b_e_L[i];
			out->v_b_e_L[i] = state->v_b_e_L[i];
			out->w_b_e_L[i] = xforms->w_b_e_L[i];
			out->v_b_e_B[i] = xforms->v_b_e_B[i];
			out->w_b_e_B[i] = state->w_b_e_B[i];
			out->a_b_e_L[i] = std->v_b_e_L[i];


		}
		out->altitudeAGL = -out->p_b_e_L[2] - vehicleMotion.env->terrainAlt;
		out->rpm = state->omega / (2.0 * C_PI) * 60;
	}
	else {
		for (int i = 0; i < 3; i++)
		{
			out->p_b_e_L[i] = out->kf_gps_position[i];
			out->v_b_e_L[i] = out->kf_gps_velocity[i];
			out->w_b_e_B[i] = out->kf_imu_angular[i];
		}
	}

	/* express acceleration in body axis */
	map_vector(xforms->dcm_lb, out->a_b_e_L, out->a_b_e_B);

	for (int i = 0; i < 4; i++)
	{
		out->q[i] = state->e[i];
	}

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			out->dcm_bl[i][j] = xforms->dcm_bl[i][j];
			out->dcm_lb[i][j] = xforms->dcm_lb[i][j];
		}
	}
	dcm2euler(out->dcm_bl, &(out->phi), &(out->theta), &(out->psi));
}