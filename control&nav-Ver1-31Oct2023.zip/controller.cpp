#include "rmax/onboard_ref.h"
#include "rmax/navigation_ref.h"
#include "rmax/controller_ref.h"
#include "rmax/controller.h"
#include "esim/util.h"

// just for a demonstration
#include <time.h>
#include <random>
unsigned char seed = 0;
double randomController( double a, double b ) {
	if ( 0 == seed )
	{
		seed = 1;
		srand( (unsigned int ) time( 0 ) );
	}
	double random = ( ( double ) rand() ) / ( double ) RAND_MAX;
	double diff = b - a;
	double r = random * diff;
	return a + r;
}

#define MIN_PWM 1000
#define MAX_PWM 2000

void updateControl ( struct onboard_ref* ob )
{
	struct navout_ref* nav = ob->navigation->out; // navigation results
	struct onboardControl_ref* cntrl = ob->control; // controller
	struct actuatorInt_ref* act = ob->actuators; // actuators
	struct obDatalink_ref* data = ob->datalink; // datalink messages

	struct datalinkMessagePWM_ref* pwmout = act->pwmFromUs; // pwm to ESCs

	// basic controller

	const double pi = 3.14159265359 ;

	cntrl->posError[0] = cntrl->desXpos - nav->p_b_e_L[0] ;
	cntrl->posError[1] = cntrl->desYpos - nav->p_b_e_L[1] ;
	cntrl->posErrorHeading[0] = + cntrl->posError[0] * cos(nav->psi) + cntrl->posError[1] * sin(nav->psi) ;
	cntrl->posErrorHeading[1] = - cntrl->posError[0] * sin(nav->psi) + cntrl->posError[1] * cos(nav->psi) ;

	cntrl->velErrorHeading[0] = ( + nav->v_b_e_L[0] * cos(nav->psi) + nav->v_b_e_L[1] * sin(nav->psi)) ;
	cntrl->velErrorHeading[1] = ( - nav->v_b_e_L[0] * sin(nav->psi) + nav->v_b_e_L[1] * cos(nav->psi)) ;

	cntrl->velCmd[0] = LIMIT( (cntrl->K_PosX * cntrl->posErrorHeading[0] ) / cntrl->K_DotX, - cntrl->maxVel * 5280 / 3600 , cntrl->maxVel * 5280 / 3600) ;
	cntrl->velCmd[1] = LIMIT( (cntrl->K_PosY * cntrl->posErrorHeading[1] ) / cntrl->K_DotY, - cntrl->maxVel * 5280 / 3600, cntrl->maxVel * 5280 / 3600) ;
 
	cntrl->phiCmd   = + (cntrl->K_DotY / cntrl->gravity * (cntrl->velCmd[1] - cntrl->velErrorHeading[1])) ;
	cntrl->thetaCmd = - (cntrl->K_DotX / cntrl->gravity * (cntrl->velCmd[0] - cntrl->velErrorHeading[0])) ;

	cntrl->altIntegral += cntrl->work->dt * ( - cntrl->desAlt - nav->p_b_e_L[2]);
	cntrl->altIntegral = LIMIT(cntrl->altIntegral, -cntrl->integralLimit, cntrl->integralLimit);

	act->work->c_delf[0] = - cntrl->K_PosAlt  * ( - cntrl->desAlt - nav->p_b_e_L[2])
						   - cntrl->K_IntAlt  * cntrl->altIntegral
						   - cntrl->K_DotAlt  * -nav->v_b_e_L[2] ; 

	cntrl->phiCmd = LIMIT(cntrl->phiCmd, -cntrl->maxBank * pi / 180 , cntrl->maxBank * pi/180);
	cntrl->thetaCmd = LIMIT(cntrl->thetaCmd, -cntrl->maxBank, cntrl->maxBank);

	act->work->c_delm[0] = cntrl->K_Roll  * (cntrl->phiCmd - nav->phi)			            - cntrl->K_DotRoll  * nav->w_b_e_B[0];
	act->work->c_delm[1] = cntrl->K_Pitch * (cntrl->thetaCmd - nav->theta)		            - cntrl->K_DotPitch * nav->w_b_e_B[1];
	act->work->c_delm[2] = cntrl->K_Yaw   * hmodRad(cntrl->psiCmd * pi / 180 - nav->psi)    - cntrl->K_DotYaw   * nav->w_b_e_B[2];
	
	// modes
	if ( -1 == data->up0->button[1] ) 
	{
		data->m0->autopilot = 0; // manual mode
	}
	else if ( 0 == data->up0->button[1] )
	{
		data->m0->autopilot = 0; // manual mode
	}
	else if ( 1 == data->up0->button[1] ) 
	{
		data->m0->autopilot = 1; // auto mode

		// act commands sent to GCS is replaced by controller output

		act->work->delf[0] = act->work->c_delf[0];
		act->work->delm[0] = act->work->c_delm[0];
		act->work->delm[1] = act->work->c_delm[1];
		act->work->delm[2] = act->work->c_delm[2];

	}

	// mixer
	if ( 1 == data->up0->button[0] ) // arm
	{
		data->m0->LaunchState = 1;

		// only throttle and roll
		double thr_pwm  = ( act->work->delf[0] - ( -1 ) ) * ( 2000 - 1000 ) / ( 1 - ( -1 ) ) + 1000; // from [-1,1] to [1000,2000]
		double roll_pwm = ( act->work->delm[0] - ( -1 ) ) * ( 500 - ( -500 ) ) / ( 1 - ( -1 ) ) + ( -500 ); // from [-1,1] to [-500,500]
		double pitch_pwm = (act->work->delm[1] - (-1)) * (500 - (-500)) / (1 - (-1)) + (-500); // from [-1,1] to [-500,500]
		double yaw_pwm = (act->work->delm[2] - (-1)) * (500 - (-500)) / (1 - (-1)) + (-500); // from [-1,1] to [-500,500]

		pwmout->channel[0] = ( unsigned short ) LIMIT( thr_pwm - roll_pwm + pitch_pwm + yaw_pwm , MIN_PWM, MAX_PWM ); // front-right CW
		pwmout->channel[1] = ( unsigned short ) LIMIT( thr_pwm - roll_pwm - pitch_pwm - yaw_pwm , MIN_PWM, MAX_PWM ); // back-right  CCW
		pwmout->channel[2] = ( unsigned short ) LIMIT( thr_pwm + roll_pwm - pitch_pwm + yaw_pwm , MIN_PWM, MAX_PWM); // back-left   CW
		pwmout->channel[3] = ( unsigned short ) LIMIT( thr_pwm + roll_pwm + pitch_pwm - yaw_pwm , MIN_PWM, MAX_PWM ); // back-right  CCW
	}
	else // disarm
	{
		data->m0->LaunchState = 0;
		for ( unsigned int i = 0; i < 4; i++ )
		{
			pwmout->channel[i] = MIN_PWM;
		}
	}
}